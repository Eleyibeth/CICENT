<?php  ob_start();

session_start();


include_once('db.php');
include_once('functions.php');

?>