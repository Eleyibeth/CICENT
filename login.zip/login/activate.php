<?php include_once('../login/includes/header.php'); ?>

<?php include_once('../login/includes/nav.php'); ?>


	<div class="container">
		<div class="jumbotron">
			<h1 class="text-center"> <?php activate_user(); ?></h1>
		</div>
	
<?php include_once('../login/includes/footer.php'); ?>